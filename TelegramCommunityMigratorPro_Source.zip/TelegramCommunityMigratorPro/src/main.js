const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const https = require('https');
const Database = require('better-sqlite3');

let db;
function requestTelegram(token, method, payload = {}) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify(payload);
    const req = https.request({
      hostname: 'api.telegram.org', path: `/bot${token}/${method}`, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
    }, res => {
      let data = ''; res.setEncoding('utf8'); res.on('data', c => data += c);
      res.on('end', () => {
        try { const parsed = JSON.parse(data); if (!parsed.ok) return reject(new Error(parsed.description || 'Telegram API error')); resolve(parsed.result); }
        catch (e) { reject(e); }
      });
    });
    req.on('error', reject); req.setTimeout(20000, () => req.destroy(new Error('Telegram request timed out'))); req.write(body); req.end();
  });
}
function initDb() {
  const dir = app.getPath('userData'); fs.mkdirSync(dir, { recursive: true });
  db = new Database(path.join(dir, 'community-migrator.sqlite'));
  db.pragma('journal_mode = WAL');
  db.exec(`
    CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS groups (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, chat_ref TEXT NOT NULL UNIQUE, kind TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS members (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, username TEXT, telegram_id TEXT, source TEXT, destination TEXT, consent INTEGER NOT NULL DEFAULT 0, consent_at TEXT, invite_link TEXT, status TEXT DEFAULT 'Imported', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS history (id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL, details TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
  `);
}
function setting(key) { return db.prepare('SELECT value FROM settings WHERE key=?').get(key)?.value || ''; }
function setSetting(key, value) { db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(key, String(value)); }
function log(action, details='') { db.prepare('INSERT INTO history(action,details) VALUES(?,?)').run(action, details); }
function createWindow() {
  const win = new BrowserWindow({ width: 1280, height: 820, minWidth: 1000, minHeight: 680, backgroundColor: '#0b1020', title: 'Telegram Community Migrator Pro', webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
  win.loadFile(path.join(__dirname, 'index.html'));
}

ipcMain.handle('app:overview', () => ({ members: db.prepare('SELECT COUNT(*) n FROM members').get().n, consented: db.prepare('SELECT COUNT(*) n FROM members WHERE consent=1').get().n, groups: db.prepare('SELECT COUNT(*) n FROM groups').get().n, invitations: db.prepare("SELECT COUNT(*) n FROM members WHERE invite_link IS NOT NULL AND invite_link != ''").get().n, botName: setting('bot_name') }));
ipcMain.handle('telegram:connect', async (_, token) => {
  if (!token || !/^\d+:[A-Za-z0-9_-]{20,}$/.test(token.trim())) throw new Error('Enter a valid Telegram bot token from @BotFather.');
  const me = await requestTelegram(token.trim(), 'getMe'); setSetting('bot_token', token.trim()); setSetting('bot_name', '@' + me.username); log('Telegram connected', '@' + me.username); return { username: '@' + me.username, firstName: me.first_name };
});
ipcMain.handle('telegram:status', async () => { const token = setting('bot_token'); if (!token) return { connected:false }; const me = await requestTelegram(token, 'getMe'); return { connected:true, username:'@'+me.username }; });
ipcMain.handle('telegram:checkChat', async (_, chatRef) => { const token=setting('bot_token'); if(!token) throw new Error('Connect a Telegram bot first.'); const chat=await requestTelegram(token,'getChat',{chat_id:chatRef}); return {id:String(chat.id), title:chat.title || chat.username || chat.first_name || chatRef, type:chat.type}; });
ipcMain.handle('groups:add', (_, data) => { const info=db.prepare('INSERT INTO groups(title,chat_ref,kind) VALUES(?,?,?)').run(data.title,data.chatRef,data.kind); log('Group saved',`${data.kind}: ${data.title} (${data.chatRef})`); return {id:info.lastInsertRowid}; });
ipcMain.handle('groups:list', () => db.prepare('SELECT * FROM groups ORDER BY created_at DESC').all());
ipcMain.handle('members:list', () => db.prepare('SELECT * FROM members ORDER BY created_at DESC').all());
ipcMain.handle('members:import', (_, rows) => {
  const insert=db.prepare('INSERT INTO members(name,username,telegram_id,source,destination,consent,consent_at,status) VALUES(@name,@username,@telegram_id,@source,@destination,@consent,@consent_at,@status)');
  const run=db.transaction(items=>{let added=0, skipped=0; for(const r of items){ if(!r.consent){skipped++;continue;} const exists=db.prepare('SELECT id FROM members WHERE (telegram_id<>"" AND telegram_id=?) OR (username<>"" AND username=?)').get(r.telegram_id||'',r.username||''); if(exists){skipped++;continue;} insert.run({name:r.name||'',username:(r.username||'').replace(/^@/,''),telegram_id:r.telegram_id||'',source:r.source||'',destination:r.destination||'',consent:1,consent_at:new Date().toISOString(),status:'Consent recorded'});added++;} return {added,skipped}; });
  const result=run(rows); log('Member import',`${result.added} added; ${result.skipped} skipped (no consent/duplicate)`); return result;
});
ipcMain.handle('members:consent', (_, id, consent) => { db.prepare('UPDATE members SET consent=?, consent_at=?, status=? WHERE id=?').run(consent?1:0,consent?new Date().toISOString():null,consent?'Consent recorded':'Consent withdrawn',id); log(consent?'Consent recorded':'Consent withdrawn',`Member record ${id}`); return true; });
ipcMain.handle('migration:invite', async (_, data) => {
  const token=setting('bot_token'); if(!token) throw new Error('Connect a Telegram bot first.');
  const member=db.prepare('SELECT * FROM members WHERE id=?').get(data.memberId); if(!member) throw new Error('Member record not found.'); if(!member.consent) throw new Error('This member has not consented. Invitation generation is blocked.');
  const dest=db.prepare("SELECT * FROM groups WHERE id=? AND kind='destination'").get(data.groupId); if(!dest) throw new Error('Choose a saved destination group.');
  const result=await requestTelegram(token,'createChatInviteLink',{chat_id:dest.chat_ref, creates_join_request:true, name:`Opt-in invitation ${member.id}`});
  db.prepare("UPDATE members SET destination=?,invite_link=?,status='Invitation ready' WHERE id=?").run(dest.title,result.invite_link,member.id); log('Opt-in invite created',`${member.name||member.username||member.id} → ${dest.title}`); return result.invite_link;
});
ipcMain.handle('history:list', () => db.prepare('SELECT * FROM history ORDER BY created_at DESC LIMIT 500').all());
ipcMain.handle('settings:get', () => ({botName:setting('bot_name'), databasePath:path.join(app.getPath('userData'),'community-migrator.sqlite')}));
ipcMain.handle('export:csv', async (_, rows) => { const {filePath}=await dialog.showSaveDialog({title:'Export member records',defaultPath:'telegram-members.csv',filters:[{name:'CSV',extensions:['csv']}]}); if(!filePath)return {cancelled:true}; const cols=['name','username','telegram_id','source','destination','consent','consent_at','invite_link','status']; const esc=v=>'"'+String(v??'').replace(/"/g,'""')+'"'; fs.writeFileSync(filePath,[cols.join(','),...rows.map(r=>cols.map(c=>esc(r[c])).join(','))].join('\r\n'),'utf8'); return {cancelled:false,path:filePath}; });
ipcMain.handle('dialog:importCsv', async () => { const r=await dialog.showOpenDialog({properties:['openFile'],filters:[{name:'CSV files',extensions:['csv']}]}); if(r.canceled||!r.filePaths[0])return {cancelled:true}; return {cancelled:false,path:r.filePaths[0],content:fs.readFileSync(r.filePaths[0],'utf8')}; });
ipcMain.handle('shell:open', (_, url) => { if(/^https:\/\//i.test(url)) return shell.openExternal(url); });
app.whenReady().then(()=>{initDb();createWindow();app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow();});});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});
