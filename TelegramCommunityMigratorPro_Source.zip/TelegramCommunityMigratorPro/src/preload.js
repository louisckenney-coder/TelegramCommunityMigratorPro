const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('tcm', {
  overview:()=>ipcRenderer.invoke('app:overview'), connect:token=>ipcRenderer.invoke('telegram:connect',token), telegramStatus:()=>ipcRenderer.invoke('telegram:status'), checkChat:ref=>ipcRenderer.invoke('telegram:checkChat',ref),
  addGroup:data=>ipcRenderer.invoke('groups:add',data), groups:()=>ipcRenderer.invoke('groups:list'), members:()=>ipcRenderer.invoke('members:list'), importMembers:rows=>ipcRenderer.invoke('members:import',rows), consent:(id,v)=>ipcRenderer.invoke('members:consent',id,v), invite:data=>ipcRenderer.invoke('migration:invite',data), history:()=>ipcRenderer.invoke('history:list'), settings:()=>ipcRenderer.invoke('settings:get'), exportCsv:rows=>ipcRenderer.invoke('export:csv',rows), importCsv:()=>ipcRenderer.invoke('dialog:importCsv'), open:url=>ipcRenderer.invoke('shell:open',url)
});
